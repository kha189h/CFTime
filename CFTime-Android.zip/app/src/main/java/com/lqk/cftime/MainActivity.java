package com.lqk.cftime;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.camera.view.PreviewView;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ = 7;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    // Nơi app hỏi xem có bản mới không (GitHub Releases của kho lưu trữ này)
    private static final String UPDATE_API = "https://api.github.com/repos/kha189h/CFTime/releases/latest";

    private WebView web;
    private NativeCam nat; // camera gốc của máy (CameraX), nằm phía sau WebView trong suốt
    private boolean loaded = false;
    private boolean asking = false;
    private PermissionRequest pendingWeb;
    private GeolocationPermissions.Callback pendingGeo;
    private String pendingGeoOrigin;
    private static final int REQ_CAM = 8;
    private ValueCallback<Uri[]> chooserCb;
    private Uri camUri;
    private File camFile;
    private File pendingApk;
    private long lastCheck = 0;

    private boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void toast(final String t) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, t, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF101114);
        PreviewView pvw = new PreviewView(this);
        pvw.setVisibility(View.GONE);
        root.addView(pvw, new FrameLayout.LayoutParams(1, 1));
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        nat = new NativeCam(this, web, pvw);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setGeolocationEnabled(true);

        // Toàn bộ app nằm trong APK (thư mục assets), chạy hoàn toàn không cần mạng
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/cap/", new WebViewAssetLoader.InternalStoragePathHandler(this, nat.dir()))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest r) {
                handleWebPermission(r);
            }

            // Nút chụp khi camera trực tiếp lỗi: mở camera hệ thống rồi trả ảnh về trang để đóng dấu
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    File dir = new File(getCacheDir(), "cam");
                    dir.mkdirs();
                    camFile = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
                    camUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", camFile);
                    Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                    i.setClipData(ClipData.newRawUri("", camUri));
                    i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(i, REQ_CAM);
                } catch (Exception e) {
                    chooserCb = null;
                    cb.onReceiveValue(null);
                    toast("Không mở được camera của máy");
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    cb.invoke(origin, true, false);
                } else {
                    pendingGeo = cb;
                    pendingGeoOrigin = origin;
                    if (!asking) {
                        asking = true;
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);
                    }
                }
            }
        });
        web.addJavascriptInterface(new Bridge(), "CFNative");

        // Lần đầu: xin quyền xong mới mở giao diện, để camera không bị từ chối vì chưa kịp cấp quyền
        if (has(Manifest.permission.CAMERA)) {
            loaded = true;
            web.loadUrl(APP_URL);
        } else {
            asking = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQ);
        }
    }

    private void handleWebPermission(PermissionRequest r) {
        List<String> ok = new ArrayList<>();
        List<String> need = new ArrayList<>();
        for (String res : r.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) {
                if (has(Manifest.permission.CAMERA)) ok.add(res); else need.add(Manifest.permission.CAMERA);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                if (has(Manifest.permission.RECORD_AUDIO)) ok.add(res); else need.add(Manifest.permission.RECORD_AUDIO);
            } else {
                ok.add(res);
            }
        }
        if (need.isEmpty()) {
            r.grant(r.getResources());
        } else {
            pendingWeb = r;
            if (!asking) {
                asking = true;
                requestPermissions(need.toArray(new String[0]), REQ);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        asking = false;
        if (!loaded) {
            loaded = true;
            web.loadUrl(APP_URL);
        }
        if (pendingWeb != null) {
            List<String> ok = new ArrayList<>();
            for (String r : pendingWeb.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !has(Manifest.permission.CAMERA)) continue;
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !has(Manifest.permission.RECORD_AUDIO)) continue;
                ok.add(r);
            }
            if (ok.isEmpty()) pendingWeb.deny();
            else pendingWeb.grant(ok.toArray(new String[0]));
            pendingWeb = null;
        }
        if (pendingGeo != null) {
            boolean g = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
            pendingGeo.invoke(pendingGeoOrigin, g, false);
            pendingGeo = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAM && chooserCb != null) {
            if (res == RESULT_OK && camFile != null && camFile.length() > 0) chooserCb.onReceiveValue(new Uri[]{camUri});
            else chooserCb.onReceiveValue(null);
            chooserCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        // Nút Back: đóng bảng đang mở trong app trước, không còn gì để đóng thì thoát
        web.evaluateJavascript("(function(){if(typeof view!=='undefined'&&view!==null){view=null;render();return 1}return 0})()",
                v -> {
                    if (!"1".equals(v)) finish();
                });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nat != null) nat.stop();
        // Nhả camera trước khi app xuống nền để lần mở lại không bị kẹt camera
        web.evaluateJavascript("(function(){try{if(typeof recOn!=='undefined'&&recOn)stopRec();stopCam()}catch(e){}})()",
                v -> web.onPause());
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (loaded) {
            // Nếu camera chưa mở được (ví dụ vừa cấp quyền xong) thì tự thử lại
            web.evaluateJavascript("if(typeof start==='function')start()", null);
        }
        if (pendingApk != null && getPackageManager().canRequestPackageInstalls()) {
            File f = pendingApk;
            pendingApk = null;
            installApk(f);
        } else if (loaded && System.currentTimeMillis() - lastCheck > 30 * 60 * 1000L) {
            checkUpdate(false);
        }
    }

    @Override
    protected void onDestroy() {
        if (nat != null) nat.destroy();
        super.onDestroy();
    }

    // ---------------- Cập nhật app ----------------

    private String read(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private void checkUpdate(final boolean manual) {
        lastCheck = System.currentTimeMillis();
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_API).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                c.setRequestProperty("Accept", "application/vnd.github+json");
                int code = c.getResponseCode();
                if (code != 200) {
                    if (manual) toast("Chưa có bản cập nhật nào được phát hành (mã " + code + ")");
                    return;
                }
                JSONObject j = new JSONObject(read(c.getInputStream()));
                String tag = j.getString("tag_name");
                String url = null;
                JSONArray assets = j.getJSONArray("assets");
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject o = assets.getJSONObject(i);
                    if (o.getString("name").endsWith(".apk")) url = o.getString("browser_download_url");
                }
                long cur = getPackageManager().getPackageInfo(getPackageName(), 0).getLongVersionCode();
                long latest = Long.parseLong(tag.replaceAll("[^0-9]", ""));
                if (url != null && latest > cur) {
                    final String t = tag;
                    final String u = url;
                    runOnUiThread(() -> askUpdate(t, u));
                } else if (manual) {
                    toast("Bạn đang dùng bản mới nhất");
                }
            } catch (Exception e) {
                if (manual) toast("Không kiểm tra được. Hãy bật mạng và thử lại.");
            }
        }).start();
    }

    private void askUpdate(String tag, final String url) {
        new AlertDialog.Builder(this)
                .setTitle("Có bản cập nhật mới")
                .setMessage("Phiên bản " + tag + " đã sẵn sàng. Cập nhật ngay?")
                .setPositiveButton("Cập nhật", (d, w) -> download(url))
                .setNegativeButton("Để sau", null)
                .show();
    }

    private void download(final String url) {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Đang tải bản cập nhật...");
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setIndeterminate(false);
        pd.setMax(100);
        pd.setCancelable(false);
        pd.show();
        new Thread(() -> {
            try {
                File dir = new File(getCacheDir(), "update");
                dir.mkdirs();
                final File f = new File(dir, "CFTime.apk");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(true);
                long total = c.getContentLengthLong();
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[65536];
                    int n;
                    long got = 0;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        if (total > 0) {
                            final int p = (int) (got * 100 / total);
                            runOnUiThread(() -> pd.setProgress(p));
                        }
                    }
                }
                runOnUiThread(() -> {
                    pd.dismiss();
                    installApk(f);
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    pd.dismiss();
                    Toast.makeText(MainActivity.this, "Tải không được: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void installApk(File f) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            pendingApk = f;
            Toast.makeText(this, "Hãy bật \"Cho phép từ nguồn này\" cho CFTime, rồi quay lại app để cài.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            return;
        }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    // ---------------- Cầu nối cho trang web ----------------

    /** Đèn pin, lưu ảnh/video thẳng vào thư viện (không hiện thông báo tải xuống), phiên bản và cập nhật. */
    private class Bridge {
        private Uri uri;
        private OutputStream out;

        @JavascriptInterface
        public String version() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "?";
            }
        }

        @JavascriptInterface
        public void checkUpdate() {
            runOnUiThread(() -> MainActivity.this.checkUpdate(true));
        }

        // --- Camera gốc của máy (xem NativeCam). Kết quả trả về trang qua window.__nc(loại, dữ liệu) ---
        @JavascriptInterface
        public boolean camSupported() {
            return nat != null;
        }

        @JavascriptInterface
        public void camStart(boolean front, String ext, int x, int y, int w, int h) {
            nat.start(front, ext, x, y, w, h);
        }

        @JavascriptInterface
        public void camStop() {
            nat.stop();
        }

        @JavascriptInterface
        public void camShot(int phys, String flash) {
            nat.shoot(phys, flash);
        }

        @JavascriptInterface
        public void camZoom(double z) {
            nat.zoom((float) z);
        }

        @JavascriptInterface
        public boolean torch(boolean on) {
            try {
                CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
                for (String id : cm.getCameraIdList()) {
                    CameraCharacteristics c = cm.getCameraCharacteristics(id);
                    Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer lens = c.get(CameraCharacteristics.LENS_FACING);
                    if (Boolean.TRUE.equals(flash) && lens != null && lens == CameraCharacteristics.LENS_FACING_BACK) {
                        cm.setTorchMode(id, on);
                        return true;
                    }
                }
            } catch (Exception e) {
                // Android có thể không cho bật đèn khi camera đang mở
            }
            return false;
        }

        @JavascriptInterface
        public synchronized String saveBegin(String name, String mime) {
            try {
                boolean video = mime.startsWith("video");
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        (video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES) + "/CFTime");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri col = video
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                uri = getContentResolver().insert(col, v);
                out = getContentResolver().openOutputStream(uri);
                return "ok";
            } catch (Exception e) {
                return "err:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public synchronized String saveChunk(String b64) {
            try {
                out.write(Base64.decode(b64, Base64.DEFAULT));
                return "ok";
            } catch (Exception e) {
                return "err:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public synchronized String saveEnd() {
            try {
                out.close();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, v, null, null);
                return "ok";
            } catch (Exception e) {
                return "err:" + e.getMessage();
            }
        }
    }
}
