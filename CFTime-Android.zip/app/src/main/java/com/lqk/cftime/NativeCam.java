package com.lqk.cftime;

import android.app.Activity;
import android.view.Surface;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;

import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.core.ZoomState;
import androidx.camera.extensions.ExtensionMode;
import androidx.camera.extensions.ExtensionsManager;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;

import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONObject;

import java.io.File;
import java.util.Locale;

/**
 * Camera gốc của máy (CameraX). Ảnh chụp đi qua bộ xử lý ảnh của máy (khử nhiễu, chế độ đêm của hãng nếu có)
 * giống các app camera thông thường. Giao diện web vẫn nằm phía trên (WebView trong suốt) để vẽ dấu ngày giờ.
 * Mọi hàm công khai gọi được từ luồng bất kỳ; việc thật được chuyển sang luồng giao diện.
 */
final class NativeCam implements LifecycleOwner {
    private final Activity act;
    private final WebView web;
    private final PreviewView pv;
    private final LifecycleRegistry reg = new LifecycleRegistry(this);
    private final File dir;
    private ProcessCameraProvider provider;
    private ImageCapture capture;
    private Camera camera;
    private int gen = 0; // tăng mỗi lần mở/tắt, để bỏ qua kết quả của lần mở đã cũ

    NativeCam(Activity a, WebView w, PreviewView p) {
        act = a;
        web = w;
        pv = p;
        dir = new File(a.getCacheDir(), "cap");
        dir.mkdirs();
        pv.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        pv.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        reg.setCurrentState(Lifecycle.State.STARTED);
    }

    @Override
    public Lifecycle getLifecycle() {
        return reg;
    }

    /** Thư mục chứa ảnh vừa chụp (trang web đọc qua /cap/). */
    File dir() {
        return dir;
    }

    private void js(String type, String data) {
        final String code = "window.__nc&&window.__nc(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")";
        act.runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private void fail(int g, Throwable t) {
        if (g != gen) return;
        String m = t.getMessage();
        js("error", t.getClass().getSimpleName() + (m == null ? "" : ": " + m));
    }

    /** Mở camera và đặt khung xem trước tại (x, y, w, h) tính bằng điểm ảnh của màn hình. ext: none, auto hoặc night. */
    void start(final boolean front, final String ext, final int x, final int y, final int w, final int h) {
        act.runOnUiThread(() -> {
            final int g = ++gen;
            try {
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(w, 1), Math.max(h, 1));
                lp.leftMargin = x;
                lp.topMargin = y;
                pv.setLayoutParams(lp);
                pv.setVisibility(View.VISIBLE);
                final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(act);
                f.addListener(() -> {
                    if (g != gen) return;
                    try {
                        provider = f.get();
                        withExtension(front, ext, g);
                    } catch (Throwable t) {
                        fail(g, t);
                    }
                }, ContextCompat.getMainExecutor(act));
            } catch (Throwable t) {
                fail(g, t);
            }
        });
    }

    // Thử bật chế độ đêm/HDR của hãng (nếu máy hỗ trợ); không được thì chụp thường
    private void withExtension(final boolean front, final String ext, final int g) throws Exception {
        final CameraSelector plain = front ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA;
        if ("none".equals(ext)) {
            bind(plain, plain, "none", g);
            return;
        }
        final ListenableFuture<ExtensionsManager> ef = ExtensionsManager.getInstanceAsync(act, provider);
        ef.addListener(() -> {
            if (g != gen) return;
            CameraSelector sel = plain;
            String used = "none";
            try {
                ExtensionsManager em = ef.get();
                int[] order = "night".equals(ext)
                        ? new int[]{ExtensionMode.NIGHT, ExtensionMode.AUTO}
                        : new int[]{ExtensionMode.AUTO, ExtensionMode.NIGHT};
                for (int m : order) {
                    if (em.isExtensionAvailable(plain, m)) {
                        sel = em.getExtensionEnabledCameraSelector(plain, m);
                        used = (m == ExtensionMode.NIGHT) ? "night" : "auto";
                        break;
                    }
                }
            } catch (Throwable t) {
                sel = plain;
                used = "none";
            }
            try {
                bind(sel, plain, used, g);
            } catch (Throwable t) {
                fail(g, t);
            }
        }, ContextCompat.getMainExecutor(act));
    }

    private void bind(CameraSelector sel, CameraSelector plain, String used, int g) throws Exception {
        try {
            bindOnce(sel, g, used);
        } catch (Exception e) {
            if ("none".equals(used)) throw e;
            bindOnce(plain, g, "none"); // chế độ của hãng lỗi: dùng camera thường
        }
    }

    @SuppressWarnings("deprecation")
    private void bindOnce(CameraSelector sel, int g, String used) throws Exception {
        Preview preview = new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build();
        preview.setSurfaceProvider(pv.getSurfaceProvider());
        ImageCapture ic = new ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build();
        provider.unbindAll();
        Camera cam = provider.bindToLifecycle(this, sel, preview, ic);
        camera = cam;
        capture = ic;
        double zmax = 5, zmin = 1;
        try {
            ZoomState zs = cam.getCameraInfo().getZoomState().getValue();
            if (zs != null) {
                zmax = zs.getMaxZoomRatio();
                zmin = zs.getMinZoomRatio();
            }
        } catch (Throwable t) {
            // giữ giá trị mặc định
        }
        boolean flash = false;
        try {
            flash = cam.getCameraInfo().hasFlashUnit();
        } catch (Throwable t) {
            // coi như không có đèn
        }
        js("ready", String.format(Locale.US, "{\"zmax\":%.2f,\"zmin\":%.2f,\"flash\":%b,\"ext\":\"%s\"}", zmax, zmin, flash, used));
    }

    /** Chụp một ảnh. phys: hướng máy (0, 90, -90, 180 độ như trang web). flash: off, auto hoặc on. */
    void shoot(final int phys, final String flash) {
        act.runOnUiThread(() -> {
            final ImageCapture ic = capture;
            if (ic == null) {
                js("shoterr", "camera chưa sẵn sàng");
                return;
            }
            try {
                cleanOld();
                ic.setTargetRotation(phys == 90 ? Surface.ROTATION_270
                        : phys == -90 ? Surface.ROTATION_90
                        : phys == 180 ? Surface.ROTATION_180 : Surface.ROTATION_0);
                ic.setFlashMode("on".equals(flash) ? ImageCapture.FLASH_MODE_ON
                        : "auto".equals(flash) ? ImageCapture.FLASH_MODE_AUTO : ImageCapture.FLASH_MODE_OFF);
                final File f = new File(dir, "cap_" + System.currentTimeMillis() + ".jpg");
                ImageCapture.OutputFileOptions o = new ImageCapture.OutputFileOptions.Builder(f).build();
                ic.takePicture(o, ContextCompat.getMainExecutor(act), new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults r) {
                        js("photo", f.getName());
                    }

                    @Override
                    public void onError(ImageCaptureException e) {
                        js("shoterr", "chụp lỗi: " + e.getMessage());
                    }
                });
            } catch (Throwable t) {
                js("shoterr", "chụp lỗi: " + t.getMessage());
            }
        });
    }

    private void cleanOld() {
        File[] all = dir.listFiles();
        if (all == null) return;
        long now = System.currentTimeMillis();
        for (File x : all) {
            if (now - x.lastModified() > 120000L) x.delete();
        }
    }

    void zoom(final float z) {
        act.runOnUiThread(() -> {
            Camera c = camera;
            if (c == null) return;
            try {
                c.getCameraControl().setZoomRatio(z);
            } catch (Throwable t) {
                // bỏ qua
            }
        });
    }

    /** Bật/tắt đèn pin sáng liên tục của camera đang mở (camera trước thường không có đèn nên không có tác dụng). */
    void torch(final boolean on) {
        act.runOnUiThread(() -> {
            Camera c = camera;
            if (c == null) return;
            try {
                c.getCameraControl().enableTorch(on);
            } catch (Throwable t) {
                // bỏ qua
            }
        });
    }

    void stop() {
        act.runOnUiThread(() -> {
            gen++;
            try {
                if (provider != null) provider.unbindAll();
            } catch (Throwable t) {
                // bỏ qua
            }
            camera = null;
            capture = null;
            pv.setVisibility(View.GONE);
        });
    }

    void destroy() {
        try {
            if (provider != null) provider.unbindAll();
        } catch (Throwable t) {
            // bỏ qua
        }
        camera = null;
        capture = null;
        reg.setCurrentState(Lifecycle.State.DESTROYED);
    }
}
